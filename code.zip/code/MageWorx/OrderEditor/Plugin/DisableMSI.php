<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Plugin;

class DisableMSI
{
    /**
     * @var bool
     */
    private $disableMSI = false;

    /**
     * @param $subject
     * @param $proceed
     * @param mixed ...$args
     * @return bool
     */
    public function aroundExecute($subject, $proceed, ...$args): bool
    {
        if ($this->disableMSI) {
            return true;
        }

        return $proceed(...$args);
    }

    /**
     * @param bool $flag
     */
    public function setMsiDisabledFlag(bool $flag)
    {
        $this->disableMSI = $flag;
    }
}
