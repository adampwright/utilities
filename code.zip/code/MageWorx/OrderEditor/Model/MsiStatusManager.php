<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Model;

use MageWorx\OrderEditor\Plugin\DisableMSI;

/**
 * Class MsiStatusManager
 */
class MsiStatusManager
{
    /**
     * @var DisableMSI
     */
    private $disableMSIPlugin;

    /**
     * MsiStatusManager constructor.
     *
     * @param DisableMSI $disableMSIPlugin
     */
    public function __construct(
        DisableMSI $disableMSIPlugin
    ) {
        $this->disableMSIPlugin  = $disableMSIPlugin;
    }

    /**
     * @return void
     */
    public function disableMSI()
    {
        $this->disableMSIPlugin->setMsiDisabledFlag(true);
    }

    /**
     * @return void
     */
    public function enableMSI()
    {
        $this->disableMSIPlugin->setMsiDisabledFlag(false);
    }
}
