<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Model\ResourceModel;

use Magento\Sales\Model\ResourceModel\Order\Shipment as OriginalResourceModel;

/**
 * Class Shipment
 */
class Shipment extends OriginalResourceModel
{

}
