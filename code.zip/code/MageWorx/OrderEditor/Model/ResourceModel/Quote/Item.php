<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Model\ResourceModel\Quote;

use Magento\Quote\Model\ResourceModel\Quote\Item as OriginalResourceModel;

/**
 * Class Item
 */
class Item extends OriginalResourceModel
{

}
